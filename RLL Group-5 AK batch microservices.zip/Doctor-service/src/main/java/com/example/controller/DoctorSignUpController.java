package com.example.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.DoctorSignUpRepository;
import com.example.exception.ResourceNotFoundException;
import com.example.model.Doctor;
import com.example.service.DoctorSignUpService;


@RestController
public class DoctorSignUpController {
	@Autowired
	private DoctorSignUpRepository doctorsignuprepository;
	
	private Logger log = LoggerFactory.getLogger(DoctorSignUpController.class);
	
	
	@GetMapping("/doctors")
	
	public List<Doctor> getAllDoctors()
	{
		log.debug("In getAllDoctors with return value Doctors: " );
		return doctorsignuprepository.findAll();
		}


	
	@GetMapping("/doctors/{d_id}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable  int d_id) throws ResourceNotFoundException {
		log.debug("In getDoctorById with Id:" + d_id);
		Doctor doctor=doctorsignuprepository.findById(d_id).orElseThrow(() ->new ResourceNotFoundException("Doctor not exist with id :" +d_id));
		log.debug("In getDoctorById with return value Doctor: " + doctor);
		return  ResponseEntity.ok(doctor);
	}
	
	@PutMapping("/doctors/{d_id}")
	public ResponseEntity<Doctor> updateDoctor(@PathVariable int d_id, @RequestBody Doctor doctor) throws ResourceNotFoundException
	{
		log.debug("In updateDoctor with Id:" + d_id);
		Doctor d= doctorsignuprepository.findById(d_id).orElseThrow(() ->new ResourceNotFoundException("Doctor not exist with id :" +d_id));
		d.setD_name(doctor.getD_name());
		d.setGender(doctor.getGender());
		d.setUsername(doctor.getUsername());
		d.setPassword(doctor.getPassword());
		d.setContact_no(doctor.getContact_no());
		d.setAddress(doctor.getAddress());
		d.setSpecialization(doctor.getSpecialization());
		d.setExperience(doctor.getExperience());
		d.setSalary(doctor.getSalary());
		d.setAccept(doctor.getAccept());
		
		 Doctor updatedDoctor = doctorsignuprepository.save(d);
		 log.debug("In updateDoctor with return value Doctor: " + updatedDoctor);
		return ResponseEntity.ok(updatedDoctor);
	}

	
	@PostMapping("/doctors")
	public Doctor addDoctorSignUp(@RequestBody Doctor d) {
		log.debug("In addDoctorSignUp with Doctor: " + d);
		Doctor doctorsignup = doctorsignuprepository.save(d);
		log.debug("In addDoctorSignUp with return value Doctor: " + doctorsignup);

		return doctorsignup;
	}



	@DeleteMapping(value = "/doctors/{d_id}")
	public ResponseEntity< Map<String, Boolean>> deleteDoctor(@PathVariable int d_id ) throws ResourceNotFoundException
	{
		log.debug("In deleteDoctor with Id:" + d_id);
		Doctor d= doctorsignuprepository.findById(d_id)
				.orElseThrow(() ->new ResourceNotFoundException("Doctor not exist with id :" +d_id));
		 doctorsignuprepository.delete(d);
		 Map<String, Boolean> response = new HashMap<>();
		 response.put("deleted", Boolean.TRUE);
		 log.debug("In deleteDoctor with return value Doctor: " +response);
		 return ResponseEntity.ok(response);
	}
	
}
