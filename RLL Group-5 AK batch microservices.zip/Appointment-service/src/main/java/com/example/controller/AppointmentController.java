package com.example.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.AppointmentRepository;

import com.example.exception.ResourceNotFoundException;
import com.example.model.Appointment;



@RestController
public class AppointmentController {
	@Autowired
	private AppointmentRepository appointmentrepository;
	private static final org.slf4j.Logger log = LoggerFactory.getLogger (AppointmentController.class);
	
	@GetMapping("/appointments")
	
	public List<Appointment> getAllAppointments()
	{log.debug("In getAllAppointments handler method...");
		return appointmentrepository.findAll();
		}


	@GetMapping("/appointments/{ap_id}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable  int ap_id) throws ResourceNotFoundException {
		log.debug("In getAppointmnentById with Id:"+ap_id);
		Appointment appointment=appointmentrepository.findById(ap_id).orElseThrow(() ->new ResourceNotFoundException("Appointment not exist with id :" +ap_id));
		log.debug("In getAppointmentById with return value appointment:"+appointment);

		return  ResponseEntity.ok(appointment);
	}
	//update doctors
	@PutMapping("/appointments/{ap_id}")
	public ResponseEntity<Appointment> updateAppointment(@PathVariable int ap_id, @RequestBody Appointment appointment) throws ResourceNotFoundException
	{
		 log.debug("In UpdateAppointmnentById with Id:"+ap_id);
		Appointment a=appointmentrepository.findById(ap_id).orElseThrow(() ->new ResourceNotFoundException("Appointment not exist with id :" +ap_id));
		a.setD_name(appointment.getD_name());
		a.setGender(appointment.getGender());
		a.setP_name(appointment.getP_name());
		a.setAp_date(appointment.getAp_date());
		a.setAp_time(appointment.getAp_time());
		a.setAddress(appointment.getAddress());
		a.setDisease(appointment.getDisease());
		Appointment updatedAppointment = appointmentrepository.save(a);
		log.debug("In UpdateAppointmentById with return value appointment:"+updatedAppointment);
		return ResponseEntity.ok(updatedAppointment);
	}

	
	@PostMapping("/appointments")
	public ResponseEntity <Appointment> addAppointment(@RequestBody Appointment a) {
		log.debug("In PostAppointmnent:");
		Appointment appointment = appointmentrepository.save(a);
		log.debug("In PostAppointmnent:"+appointment);
		return ResponseEntity.ok(appointment);
	}



	@DeleteMapping(value = "/appointments/{ap_id}")
	public ResponseEntity< Map<String, Boolean>> deleteAppointment(@PathVariable int ap_id ) throws ResourceNotFoundException
	{
		 log.debug("In DeleteAppointmnentById with Id:"+ap_id);
		Appointment a= appointmentrepository.findById(ap_id)
				.orElseThrow(() ->new ResourceNotFoundException("Appointment not exist with id :" +ap_id));
		appointmentrepository.delete(a);
		 Map<String, Boolean> response = new HashMap<>();
		 response.put("deleted", Boolean.TRUE);
		 log.debug("In DeleteAppointmentById with return value appointment:"+response);
		 return ResponseEntity.ok(response);
	}
	
}
