package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.dao.AppointmentRepository;
import com.example.model.Appointment;
@Service
public class AppointmentService {
	@Autowired
	AppointmentRepository AppointmentRepository;
	
	
	public List<Appointment> fetchAppointments() {
		List<Appointment> appointmentList=AppointmentRepository.findAll();
		return appointmentList;
		
	}
	
	public Appointment saveAppointment(Appointment appointment) {
		
		return AppointmentRepository.save(appointment);
		
	}
	
	public void updateAppointment(Appointment appo) {
		AppointmentRepository.save(appo);	
	
	}
	
	
	public void deleteAppointment(int ap_id) {
			
		System.out.println("service method called");
           AppointmentRepository.deleteById(ap_id);
	
	}
	 
	  public Appointment getAppointment(int ap_id) { 
	  Optional<Appointment> optional= AppointmentRepository.findById(ap_id);
	  Appointment a=optional.get();
	  return a;
	  }
	
}
