package com.example.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.PatientSignUpRepository;

import com.example.model.PatientSignUp;
@Service
public class PatientSignUpService {
	@Autowired
	PatientSignUpRepository patientsignupRepository;
	

	public List<PatientSignUp> fetchPatients() {
		List<PatientSignUp> patientsignupList=patientsignupRepository.findAll();
		return patientsignupList;
		
	}
	
	
	public PatientSignUp savePatientSignUp(PatientSignUp patientsignup) {
		return patientsignupRepository.save(patientsignup);
		
	}
	
	
	public void update(PatientSignUp p) {
		patientsignupRepository.save(p);	
	
	}
	
	
	public void deletePatient(int p_id) {	
		System.out.println("service method called");
		patientsignupRepository.deleteById(p_id);
	
	}
	
	 
	  public PatientSignUp getPatient(int p_id) { 
	  Optional<PatientSignUp> optional= patientsignupRepository.findById(p_id);
	  PatientSignUp p=optional.get();
	  return p;
	  }
	  
	
}