package com.example.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.dao.PatientLoginRepository;
import com.example.model.AuthenticationStatus;

import com.example.model.PatientLogin;
@Service
public class PatientLoginService {

	@Autowired
	PatientLoginRepository patientloginRepository;
	public AuthenticationStatus validatePatientLogin(String username, String password) {
		AuthenticationStatus status = null;
		PatientLogin patientlogin = patientloginRepository.validatePatientLogin(username, password);
		if(patientlogin!=null) {
			status = new AuthenticationStatus(patientlogin.getUsername(), patientlogin.getPassword(), true);
		}
		else {
			status = new AuthenticationStatus(null, null, false);
		}
		return status;
	}
}