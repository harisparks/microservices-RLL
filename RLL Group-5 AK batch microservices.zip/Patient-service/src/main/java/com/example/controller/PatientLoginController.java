package com.example.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.PatientLoginRepository;
import com.example.model.AuthenticationStatus;

import com.example.model.PatientLogin;
import com.example.service.PatientLoginService;


@RestController
public class PatientLoginController {
	@Autowired
	PatientLoginService patientloginService;
	
	private Logger log = LoggerFactory.getLogger(PatientLoginController.class);
	@PostMapping("/patientlogin")
	public ResponseEntity<AuthenticationStatus> validatePatientLogin(@RequestBody PatientLogin patientlogin) 		
	{
		log.debug("In validatePatientLogin with PatientLogin: " + patientlogin);
			System.out.println(patientlogin.getUsername()+" "+patientlogin.getPassword());
			AuthenticationStatus status =patientloginService.validatePatientLogin(patientlogin.getUsername(), patientlogin.getPassword());
			log.debug("In validatePatientLogin with return value patientLogin: " + status);
			return new ResponseEntity<AuthenticationStatus>(status, HttpStatus.OK);
			
		}


}