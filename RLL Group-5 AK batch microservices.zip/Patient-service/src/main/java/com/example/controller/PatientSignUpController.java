package com.example.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.PatientSignUpRepository;
import com.example.exception.ResourceNotFoundException;

import com.example.model.PatientSignUp;
import com.example.service.PatientSignUpService;


@RestController
public class PatientSignUpController {
	@Autowired
	private PatientSignUpRepository patientsignuprepository;
	PatientSignUpService patientsignupService;

	 private Logger log = LoggerFactory.getLogger(PatientSignUpController.class);

	@GetMapping("/patients")
	public List<PatientSignUp> getPatients() {
		
		 log.debug("In getAllPatients");
		return patientsignuprepository.findAll();

	}

	
	@GetMapping("/patients/{p_id}")
	public Optional<PatientSignUp> getPatientById(@PathVariable int p_id) {
		log.debug("In getPatientById with Id: " + p_id);
		Optional<PatientSignUp> p= patientsignuprepository.findById(p_id);
		log.debug("In getPatientById with return value Patient: " + p);
		return p;
	}

	

	@PostMapping("/patients")
	public PatientSignUp addPatientSignUp(@RequestBody PatientSignUp  p) {
		log.debug("In addPatientSignUp with Patient: " + p);
		PatientSignUp patientsignup = patientsignuprepository.save(p);
		log.debug("In addPatientSignUp with return value Patient: " + patientsignup);
		return patientsignup;
	}


	@PutMapping("/patients/{p_id}")
	public ResponseEntity<PatientSignUp> updatePatientSignUp(@PathVariable int p_id, @RequestBody PatientSignUp patients) throws ResourceNotFoundException
	{
		log.debug("In updatePatient with Id: " + p_id);
		PatientSignUp p= patientsignuprepository.findById(p_id).orElseThrow(() ->new ResourceNotFoundException("Patients not exist with id :" +p_id));
		p.setP_id(patients.getP_id());
		p.setP_name(patients.getP_name());
		p.setP_gender(patients.getP_gender());
		p.setUsername(patients.getUsername());
		p.setPassword(patients.getPassword());
		p.setP_contact_no(patients.getP_contact_no());

		 PatientSignUp updatedPatientsignup = patientsignuprepository.save(p);
		 log.debug("In updatePatient with return value Patient: " + updatedPatientsignup);
		return ResponseEntity.ok(updatedPatientsignup);
	}
	

	@DeleteMapping(value = "/patients/{p_id}")
	public ResponseEntity< Map<String, Boolean>> deletePatient(@PathVariable int p_id ) throws ResourceNotFoundException
	{
		 log.debug("In deletePatient with Id: " + p_id);
	PatientSignUp p= patientsignuprepository.findById(p_id)
				.orElseThrow(() ->new ResourceNotFoundException("patients not exist with id :" +p_id));
		patientsignuprepository.delete(p);
		 Map<String, Boolean> response = new HashMap<>();
		 response.put("deleted", Boolean.TRUE);
		 log.debug("In deletePatient with return value Patient: " + response);
		 return ResponseEntity.ok(response);
	}
}