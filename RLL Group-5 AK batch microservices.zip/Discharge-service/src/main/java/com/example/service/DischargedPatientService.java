package com.example.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.DischargedPatientRepository;

import com.example.model.DischargedPatient;

@Service
public class DischargedPatientService {
	@Autowired
	DischargedPatientRepository dischargedpatientepository;
	
	public List<DischargedPatient> fetchDischargedpatient() {
		List<DischargedPatient> dischargedlist=dischargedpatientepository.findAll();
		return dischargedlist;
		
	}
	
	public DischargedPatient saveDischargedPatient(DischargedPatient dischargedpatient) {
		
		return dischargedpatientepository.save(dischargedpatient);
		
	}
}
