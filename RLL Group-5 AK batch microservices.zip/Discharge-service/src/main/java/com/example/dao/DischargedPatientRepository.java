package com.example.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.DischargedPatient;


public interface DischargedPatientRepository  extends JpaRepository<DischargedPatient,Integer> {

}
