package com.example.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.PatientSignUp;
import com.example.service.PatientSignUpService;

@RestController
@Scope("request")
public class PatientSignUpController {

    @Autowired
    private PatientSignUpService patientSignUpService;

    private Logger log = LoggerFactory.getLogger(PatientSignUpController.class);

    @GetMapping("/get-patients/{p_id}")
    public ResponseEntity<PatientSignUp> getPatientById(@PathVariable("p_id") int p_id) {
        log.debug("In getPatientById with Id: " + p_id);
        ResponseEntity<PatientSignUp> patient = patientSignUpService.getPatientById(p_id);
        log.debug("In getPatientById with return value Patient: " + patient);
        return patient;
    }

    @GetMapping("/get-patients")
    public List<PatientSignUp> getAllPatients() {
        log.debug("In getAllPatients");
        List<PatientSignUp> patients = patientSignUpService.getAllPatients();
        log.debug("In getAllPatients with return value Patients: " + patients);
        return patients;
    }

    @PutMapping("/put-patients/{p_id}")
    public ResponseEntity<PatientSignUp> updatePatient(@PathVariable("p_id") int p_id, @RequestBody PatientSignUp patient) {
        log.debug("In updatePatient with Id: " + p_id);
        ResponseEntity<PatientSignUp> updatedPatient = patientSignUpService.updatePatientSignUp(p_id, patient);
        log.debug("In updatePatient with return value Patient: " + updatedPatient);
        return updatedPatient;
    }

    @PostMapping(value = "/post-patients")
    public PatientSignUp addPatientSignUp(@RequestBody PatientSignUp patient) {
        log.debug("In addPatientSignUp with Patient: " + patient);
        PatientSignUp addedPatient = patientSignUpService.addPatientSignUp(patient);
        log.debug("In addPatientSignUp with return value Patient: " + addedPatient);
        return addedPatient;
    }

    @DeleteMapping("/delete-patients/{p_id}")
    public ResponseEntity<Map<String, Boolean>> deletePatient(@PathVariable("p_id") int p_id) {
        log.debug("In deletePatient with Id: " + p_id);
        ResponseEntity<Map<String, Boolean>> deletedPatient = patientSignUpService.deletePatient(p_id);
        log.debug("In deletePatient with return value Patient: " + deletedPatient);
        return deletedPatient;
    }
}
