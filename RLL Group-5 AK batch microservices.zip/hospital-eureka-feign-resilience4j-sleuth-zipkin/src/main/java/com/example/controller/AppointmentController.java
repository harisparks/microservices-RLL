package com.example.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.model.Appointment;
import com.example.service.AppointmentService;

@RestController
@Scope("request")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;
	private static final org.slf4j.Logger log = LoggerFactory.getLogger (AppointmentController.class);

	@GetMapping("/get-appointments/{ap_id}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable("ap_id") int ap_id) {
		log.debug("In getAppointmnentById with Id:"+ap_id);
        ResponseEntity<Appointment> appointment = appointmentService.getAppointmentById(ap_id);
        log.debug("In getAppointmentById with return value appointment:"+appointment);
		return appointment;
	}
	
	@GetMapping("/get-appointments")
	public List<Appointment> getAllAppointments() {
		log.debug("In getAllAppointments handler method...");
		List<Appointment> appointment = appointmentService.getAllAppointments();
		log.debug("In getAllAppointments with return value appointments: " + appointment);
		return appointment;
	}
	

   @PutMapping("/update-appointments/{ap_id}") 
   public ResponseEntity<Appointment> updateAppointment(@PathVariable("ap_id") int ap_id, @RequestBody Appointment appointment){ 
	   log.debug("In UpdateAppointmnentById with Id:"+ap_id);
	   ResponseEntity<Appointment> updatedAppointment =appointmentService.updateAppointment(ap_id,appointment);
	   log.debug("In UpdateAppointmentById with return value appointment:"+updatedAppointment);
	   return updatedAppointment; 
	}
  
   	@PostMapping("/post-appointments") 
   	public ResponseEntity<Appointment> addAppointment(@RequestBody Appointment a){
   	    log.debug("In PostAppointmnent:");
   		ResponseEntity<Appointment> appointment = appointmentService.addAppointment(a);
   		log.debug("In PostAppointmnent:"+appointment);
   		return appointment;
   	}
  
  @DeleteMapping("/delete-appointments/{ap_id}") 
  public ResponseEntity<Map<String, Boolean>> deleteAppointment(@PathVariable("ap_id") int ap_id){
	  log.debug("In DeleteAppointmnentById with Id:"+ap_id);
	  ResponseEntity<Map<String, Boolean>> appointment = appointmentService.deleteAppointment(ap_id);
	  log.debug("In DeleteAppointmentById with return value appointment:"+appointment);
	  return appointment;
  }
  
 
}