package com.example.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.DischargedPatient;
import com.example.model.Doctor;
import com.example.service.DischargedPatientService;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;

@RestController
@Scope("request")
public class DischargedPatientController {

	@Autowired
	private DischargedPatientService dischargedService;
	
	private Logger log = LoggerFactory.getLogger(DischargedPatientController.class);
	
	@GetMapping("/get-dischargedpatients")
	public List<DischargedPatient> getAllDischargedPatients() {
		List<DischargedPatient> patient = dischargedService.getAllDischargedPatients();
		log.debug("In getAllDischargedPatients with return value Patients: " + patient);
		return patient;
	}
	
	@PostMapping("/post-dischargedpatients") 
   	public ResponseEntity<DischargedPatient> addDischargedPatient(@RequestBody DischargedPatient d){
		log.debug("In addDischargedPatient with Patient: " + d);
   		ResponseEntity<DischargedPatient> patient = dischargedService.addDischargedPatient(d);
   		log.debug("In addDischargedPatient with return value Patient: " + patient);
   		return patient;
   	}
}
