package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.model.Feedback;
import com.example.service.FeedbackService;

import java.util.List;
import java.util.Map;

@RestController
@Scope("request")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;
    
    private Logger log = LoggerFactory.getLogger(FeedbackController.class);

	

    @GetMapping("/get-feedbacks")
    public List<Feedback> getAllFeedbacks() {
        List<Feedback> feedbacks = feedbackService.getAllFeedbacks();
        log.debug("In getAllDoctors with return value Doctors: " + feedbacks);
        return feedbacks;
    }

	

    @PostMapping("/post-feedbacks")
    public Feedback addFeedback(@RequestBody Feedback feedback) {
    	log.debug("In addFeedback with Feedback: " + feedback);
        Feedback addedFeedback = feedbackService.addFeedback(feedback);
        log.debug("In addFeedback with return value Feedback: " + feedback);
        return addedFeedback;
    }

	
}
