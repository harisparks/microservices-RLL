package com.example.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.model.Doctor;
import com.example.service.DoctorSignUpService;

@RestController
@Scope("request")
public class DoctorSignUpController {

	@Autowired
	private DoctorSignUpService doctorService;
	
	private Logger log = LoggerFactory.getLogger(DoctorSignUpController.class);
	
	@GetMapping("/get-doctors/{d_id}")
	public Doctor getDoctorById(@PathVariable int d_id) {
		log.debug("In getDoctorById with Id:" + d_id);
		Doctor doctor = doctorService.getDoctorById(d_id);
		log.debug("In getDoctorById with return value Doctor: " + doctor);
		return doctor;
	}
	
	@GetMapping("/get-doctors")
	public List<Doctor> getAllDoctors() {
		List<Doctor> doctor = doctorService.getAllDoctors();
		log.debug("In getAllDoctors with return value Doctors: " + doctor);
		return doctor;
	}
	

   @PutMapping("/put-doctors/{d_id}") 
   public ResponseEntity<Doctor> updateDoctor(@PathVariable("d_id") int d_id, @RequestBody Doctor doctor){ 
	   log.debug("In updateDoctor with Id:" + d_id);
	   ResponseEntity<Doctor> updatedDoctor =doctorService.updateDoctor(d_id,doctor); 
	   log.debug("In updateDoctor with return value Doctor: " + updatedDoctor);
	   return updatedDoctor; 
	}
  
   	@PostMapping("/post-doctors") 
   	public ResponseEntity<Doctor> addDoctorSignUp(@RequestBody Doctor d){
   		log.debug("In addDoctorSignUp with Doctor: " + d);
   		ResponseEntity<Doctor> doctor = doctorService.addDoctorSignUp(d);
   		log.debug("In addDoctorSignUp with return value Doctor: " + doctor);
   		return doctor;
   	}
  
  @DeleteMapping("/delete-doctors/{d_id}") 
  public ResponseEntity<Map<String, Boolean>> deleteDoctor(@PathVariable("d_id") int d_id){
	  log.debug("In deleteDoctor with Id:" + d_id);
	  ResponseEntity<Map<String, Boolean>> doctor = doctorService.deleteDoctor(d_id);
	  log.debug("In deleteDoctor with return value Doctor: " + doctor);
	  return doctor;
  }
  
 
}