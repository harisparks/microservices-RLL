package com.example.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.model.AuthenticationStatus;
import com.example.model.DoctorLogin;
import com.example.service.DoctorLoginService;

import java.util.Map;

@RestController
@Scope("request")
public class DoctorLoginController {

    @Autowired
    private DoctorLoginService doctorLoginService;
    
    private Logger log = LoggerFactory.getLogger(DoctorLoginController.class);

    @PostMapping("/post-doctorlogin")
    public ResponseEntity<AuthenticationStatus> validateDoctorLogin(@RequestBody DoctorLogin doctorLogin) {
    	log.debug("In validateDoctorLogin with doctorLogin: " + doctorLogin);
    	log.debug("In validateDoctorLogin with return value doctorLogin: " + doctorLogin);
        return doctorLoginService.validateDoctorLogin(doctorLogin);
    }

   
}
