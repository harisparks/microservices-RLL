package com.example.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.AuthenticationStatus;
import com.example.model.PatientLogin;
import com.example.service.PatientLoginService;


@RestController
@Scope("request")
public class PatientLoginController {
	@Autowired
	PatientLoginService patientloginService;

	private Logger log = LoggerFactory.getLogger(PatientLoginController.class);
	
	@PostMapping("/post-patientlogin")
	public ResponseEntity<AuthenticationStatus> validatePatientLogin(@RequestBody PatientLogin patientLogin) 		
	{
		log.debug("In validatePatientLogin with PatientLogin: " + patientLogin);
		ResponseEntity<AuthenticationStatus> login=patientloginService.validatePatientLogin(patientLogin);
		log.debug("In validatePatientLogin with return value patientLogin: " + login);
		return login;
	}


}