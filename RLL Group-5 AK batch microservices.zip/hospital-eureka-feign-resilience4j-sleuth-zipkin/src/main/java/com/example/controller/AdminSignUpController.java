package com.example.controller;

import java.util.List;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.model.AdminSignUp;
import com.example.service.AdminSignUpService;
import com.example.controller.AdminSignUpController;

@RestController
@Scope("request")
public class AdminSignUpController {

	@Autowired
	private AdminSignUpService adminService;
	
	private Logger log = LoggerFactory.getLogger(AdminSignUpController.class);

   	@PostMapping(value="/post-registerAdmin") 
   	public AdminSignUp registerAdmin(@RequestBody AdminSignUp d){
   	 log.debug("Received request to register admin: {}", d);
   		AdminSignUp adminSignUp = adminService.registerAdmin(d);
   	 log.debug("Admin registered: {}", adminSignUp);
   		return adminSignUp;
   	}
  
  	@PostMapping(value="/post-adminlogin") 
   	public AdminSignUp loginuser(@RequestBody AdminSignUp d){
  		 log.debug("Received request for admin login: {}", d);
   		AdminSignUp adminSignUp = adminService.loginuser(d);
   	 log.debug("Admin logged in: {}", adminSignUp);
   		return adminSignUp;
   	}

  	@GetMapping("/get-admins/{id}")
    public ResponseEntity<AdminSignUp> getAdminById(@PathVariable("id") int id) {
        log.debug("Received request to retrieve admin with ID: {}", id);

        AdminSignUp admin = adminService.getAdminById(id);

        if (admin != null) {
            log.debug("Admin found with ID {}: {}", id, admin);
            return ResponseEntity.ok(admin);
        } else {
            log.debug("Admin not found with ID: {}", id);
            return ResponseEntity.notFound().build();
        }
    }
	
	@GetMapping("/get-admins")
	public List<AdminSignUp> getAllAdmins() {
		log.debug("Received request to retrieve all admins");
		List<AdminSignUp> admin = adminService.getAdmin();
		log.debug("Retrieved {} admins", admin.size());
		return admin;
	}
	
}