package com.example.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientSignUp {
	
	private int p_id;

	private String p_name;
	
	private String username;
	
	private String password;
	
	private String p_gender;

	private String p_contact_no;
	
	public PatientSignUp() {
	
	}
	public PatientSignUp(int p_id, String p_name,String username, String password, String p_gender, String p_contact_no) {
		super();
		this.p_id = p_id;
		this.p_name = p_name;
		this.username=username;
		this.password = password;
		this.p_gender = p_gender;
		this.p_contact_no = p_contact_no;
		
	}
	
	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username=username;
	}

	public String getP_gender() {
		return p_gender;
	}

	public void setP_gender(String p_gender) {
		this.p_gender = p_gender;
	}

	public String getP_contact_no() {
		return p_contact_no;
	}

	public void setP_contact_no(String p_contact_no) {
		this.p_contact_no = p_contact_no;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
		
}