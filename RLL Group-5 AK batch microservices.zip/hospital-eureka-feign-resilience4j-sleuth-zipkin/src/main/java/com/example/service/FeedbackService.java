package com.example.service;

import java.util.Collections;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;

import com.example.model.Feedback;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("feedback-service") 
public interface FeedbackService {
	

    @Retry(name = "feedback-service")
    @CircuitBreaker(name = "feedback-service", fallbackMethod = "fallbackMethodGetAllFeedbacks")
    @GetMapping("/feedbacks")
    public List<Feedback> getAllFeedbacks();

	
    @Retry(name = "feedback-service")
    @CircuitBreaker(name = "feedback-service", fallbackMethod = "fallbackMethodAddFeedback")
    @PostMapping("/feedbacks")
    public Feedback addFeedback(@RequestBody Feedback feedback);

	
    default List<Feedback> fallbackMethodGetAllFeedbacks(Throwable cause) {
        System.out.println("Fallback method for getAllFeedbacks() called: " + cause.getMessage());
        return Collections.emptyList(); 
    }

	
    default Feedback fallbackMethodAddFeedback(Feedback feedback, Throwable cause) {
        System.out.println("Fallback method for addFeedback() called: " + cause.getMessage());
        return new Feedback(); 
    }

	
}
