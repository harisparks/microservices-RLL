package com.example.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.model.Doctor;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("doctor-service")
public interface DoctorSignUpService {
	
	@Retry(name = "doctor-service")
	@CircuitBreaker(name = "doctor-service", fallbackMethod = "fallbackMethodgetAllDoctors")
	@GetMapping("/doctors")
	public List<Doctor> getAllDoctors();
	
	@Retry(name = "doctor-service")
	@CircuitBreaker(name = "doctor-service", fallbackMethod = "fallbackMethodgetDoctorById")
	@GetMapping("/doctors/{d_id}")
	public Doctor getDoctorById(@PathVariable int d_id) ;
	
	@Retry(name = "doctor-service")
	@CircuitBreaker(name = "doctor-service", fallbackMethod = "fallbackMethodupdateDoctor")
	@PutMapping("/doctors/{d_id}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable int d_id, @RequestBody Doctor doctor);

	@Retry(name = "doctor-service")
	@CircuitBreaker(name = "doctor-service", fallbackMethod = "fallbackMethodaddDoctorSignUp")
	@PostMapping("/doctors")
	public ResponseEntity<Doctor> addDoctorSignUp(@RequestBody Doctor d);
	
	@Retry(name = "doctor-service")
	@CircuitBreaker(name = "doctor-service", fallbackMethod = "fallbackMethoddeleteDoctor")
	@DeleteMapping("/doctors/{d_id}")
    public ResponseEntity<Map<String, Boolean>> deleteDoctor(@PathVariable int d_id);

	default List<Doctor> fallbackMethodgetAllDoctors(Throwable throwable) {
        // Fallback logic here...
        System.out.println("Fallback method for getAllDoctors() called: " + throwable.getMessage());
        return Collections.emptyList();
    }

    default Doctor fallbackMethodgetDoctorById(int d_id, Throwable throwable) {
        // Fallback logic here...
        System.out.println("Fallback method for getDoctorById() called: " + throwable.getMessage());
        return new Doctor(); // You can customize this as needed
    }

    default ResponseEntity<Doctor> fallbackMethodupdateDoctor(int d_id, Doctor doctor, Throwable throwable) {
        // Fallback logic here...
        System.out.println("Fallback method for updateDoctor() called: " + throwable.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }

    default ResponseEntity<Doctor> fallbackMethodaddDoctorSignUp(Doctor d, Throwable throwable) {
        // Fallback logic here...
        System.out.println("Fallback method for addDoctorSignUp() called: " + throwable.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }

    default ResponseEntity<Map<String, Boolean>> fallbackMethoddeleteDoctor(int d_id, Throwable throwable) {
        // Fallback logic here...
        System.out.println("Fallback method for deleteDoctor() called: " + throwable.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }

}

