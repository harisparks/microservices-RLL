package com.example.service;


import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.model.PatientSignUp;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("patient-service")
public interface PatientSignUpService {

    @Retry(name = "patient-service")
    @CircuitBreaker(name = "patient-service", fallbackMethod = "fallbackMethodGetAllPatients")
    @GetMapping(value = "/patients", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<PatientSignUp> getAllPatients();

    @Retry(name = "patient-service")
    @CircuitBreaker(name = "patient-service", fallbackMethod = "fallbackMethodGetPatientById")
    @GetMapping(value = "/patients/{p_id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PatientSignUp> getPatientById(@PathVariable("p_id") int p_id);

    @Retry(name = "patient-service")
    @CircuitBreaker(name = "patient-service", fallbackMethod = "fallbackMethodUpdatePatientSignUp")
    @PutMapping("/patients/{p_id}")
    public ResponseEntity<PatientSignUp> updatePatientSignUp(@PathVariable("p_id") int p_id, @RequestBody PatientSignUp patient);

    @Retry(name = "patient-service")
    @CircuitBreaker(name = "patient-service", fallbackMethod = "fallbackMethodAddPatientSignUp")
    @PostMapping(value = "/patients", consumes = MediaType.APPLICATION_JSON_VALUE)
    public PatientSignUp addPatientSignUp(@RequestBody PatientSignUp patient);

    @Retry(name = "patient-service")
    @CircuitBreaker(name = "patient-service", fallbackMethod = "fallbackMethodDeletePatient")
    @DeleteMapping("/patients/{p_id}")
    public ResponseEntity<Map<String, Boolean>> deletePatient(@PathVariable("p_id") int p_id);

    // Default fallback methods
    default List<PatientSignUp> fallbackMethodGetAllPatients(Throwable throwable) {
        
        System.out.println("Fallback method for getAllPatients() called: " + throwable.getMessage());
        return Collections.emptyList();
    }

    default ResponseEntity<PatientSignUp> fallbackMethodGetPatientById(int p_id, Throwable throwable) {
        
        System.out.println("Fallback method for getPatientById() called: " + throwable.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new PatientSignUp()); 
    }

    default ResponseEntity<PatientSignUp> fallbackMethodUpdatePatientSignUp(int p_id, PatientSignUp patient, Throwable throwable) {
       
        System.out.println("Fallback method for updatePatientSignUp() called: " + throwable.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }

    default PatientSignUp fallbackMethodAddPatientSignUp(PatientSignUp patient, Throwable throwable) {
       
        System.out.println("Fallback method for addPatientSignUp() called: " + throwable.getMessage());
        return new PatientSignUp(); // You can customize this as needed
    }

    default ResponseEntity<Map<String, Boolean>> fallbackMethodDeletePatient(int p_id, Throwable throwable) {
        
        System.out.println("Fallback method for deletePatient() called: " + throwable.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }
}
