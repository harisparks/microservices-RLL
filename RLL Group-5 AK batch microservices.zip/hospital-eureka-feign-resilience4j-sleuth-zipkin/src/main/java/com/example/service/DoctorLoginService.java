package com.example.service;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.model.AuthenticationStatus;
import com.example.model.DoctorLogin;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("doctor-service") 
public interface DoctorLoginService {

    @Retry(name = "doctor-service")
    @CircuitBreaker(name = "doctor-service", fallbackMethod = "fallbackMethodValidateDoctorLogin")
    @PostMapping("/doctorlogin")
    public ResponseEntity<AuthenticationStatus> validateDoctorLogin(@RequestBody DoctorLogin doctorLogin);

   
    default ResponseEntity<AuthenticationStatus> fallbackMethodValidateDoctorLogin(
        DoctorLogin doctorLogin, Throwable cause) {
        System.out.println("Fallback method for validateDoctorLogin() called: " + cause.getMessage());
       
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(
            new AuthenticationStatus(null,null,false)
        );
    }
}

