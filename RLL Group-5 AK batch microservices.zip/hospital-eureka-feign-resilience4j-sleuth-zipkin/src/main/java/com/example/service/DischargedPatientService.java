package com.example.service;

import java.util.Collections;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.model.DischargedPatient;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("discharge-service")
public interface DischargedPatientService {
	
	@Retry(name = "discharge-service")
	@CircuitBreaker(name = "discharge-service", fallbackMethod = "fallbackMethodgetAllDischargedPatients")
	@GetMapping("/dischargedpatients")
	public List<DischargedPatient> getAllDischargedPatients();
	
	@Retry(name = "discharge-service")
	@CircuitBreaker(name = "discharge-service", fallbackMethod = "fallbackMethodaddDischargedPatient")
	@PostMapping("/dischargedpatients")
	public ResponseEntity<DischargedPatient> addDischargedPatient(@RequestBody DischargedPatient d);
	
	default List<DischargedPatient> fallbackMethodgetAllDischargedPatients(Throwable throwable) {
       
        System.out.println("Fallback method for getAllDischargedPatients() called: " + throwable.getMessage());
        return Collections.emptyList();
    }
    
    
    default ResponseEntity<DischargedPatient> fallbackMethodaddDischargedPatient(DischargedPatient d, Throwable throwable) {
       
        System.out.println("Fallback method for addDischargedPatient() called: " + throwable.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}
