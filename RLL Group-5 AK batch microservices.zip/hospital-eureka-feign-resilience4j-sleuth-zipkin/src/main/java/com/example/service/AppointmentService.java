package com.example.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


import com.example.model.Appointment;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("appointment-service")
public interface AppointmentService {
    @Retry(name="appointment-service")
	@CircuitBreaker(name="appointment-service",fallbackMethod="fallbackForGetAppointments")	
    @GetMapping("/appointments")
    public List<Appointment> getAllAppointments();
	
    @Retry(name="appointment-service")
	@CircuitBreaker(name="appointment-service",fallbackMethod="fallbackForGetAppointmentById")
	@GetMapping("/appointments/{ap_id}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable  int ap_id);
    
    @Retry(name="appointment-service")
	@CircuitBreaker(name="appointment-service",fallbackMethod="fallbackForUpdateAppointments")
	@PutMapping("/appointments/{ap_id}")
	public ResponseEntity<Appointment> updateAppointment(@PathVariable int ap_id, @RequestBody Appointment appointment) ;
	
    @Retry(name="appointment-service")
	@CircuitBreaker(name="appointment-service",fallbackMethod="fallbackForPostAppointments")
	@PostMapping("/appointments")
	public ResponseEntity<Appointment> addAppointment(@RequestBody Appointment a) ;

    @Retry(name="appointment-service")
	@CircuitBreaker(name="appointment-service",fallbackMethod="fallbackForDeleteAppointments")
	@DeleteMapping(value = "/appointments/{ap_id}")
	public ResponseEntity< Map<String, Boolean>> deleteAppointment(@PathVariable int ap_id ) ;
	
	
	default ResponseEntity<Appointment> fallbackForGetAppointmentById(int ap_id,Throwable ex) {
		System.out.println("Exception raised with message ===>"+ex.getMessage());
		 String p_name = "ravi";
	        String d_name = "suresh";
	        String address = "t-nagar";
	        String gender = "male";
	        String ap_date = "25/09/2023";
	        String ap_time = "11:00AM";
	        String disease = "bone fracture";

        
        Appointment fallbackAppointment = new Appointment(ap_id, p_name, d_name, address, gender, ap_date, ap_time, disease);

        
        return new ResponseEntity<>(fallbackAppointment, HttpStatus.OK);
        
	}
	 default List<Appointment> fallbackForGetAppointments( Throwable ex) {
		 	System.out.println("Exception raised with message ===>"+ex.getMessage());
		     return Arrays.asList();
		 }
	 
	  default ResponseEntity<Appointment> fallbackForPostAppointments(@RequestBody Appointment a,Throwable ex) {
	        
		  System.out.println("Exception raised with message ===>"+ex.getMessage());
		     int ap_id=0;
		     String p_name = "ravi";
		        String d_name = "suresh";
		        String address = "t-nagar";
		        String gender = "male";
		        String ap_date = "25/09/2023";
		        String ap_time = "11:00AM";
		        String disease = "bone fracture";

	        
	        Appointment fallbackAppointment = new Appointment(ap_id, p_name, d_name, address, gender, ap_date, ap_time, disease);

	        
	        return new ResponseEntity<>(fallbackAppointment, HttpStatus.OK);
	    }
	  default ResponseEntity<Map<String, Boolean>> fallbackForDeleteAppointments(int ap_id,Throwable ex) {
		  System.out.println("Exception raised with message ===>"+ex.getMessage());
	        Map<String, Boolean> response = new HashMap<>();
	        response.put("success", false);

	       
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }
	  
	  default ResponseEntity<Appointment> fallbackForUpdateAppointments(int ap_id, @RequestBody Appointment appointment,Throwable ex) {
	        
		  System.out.println("Exception raised with message ===>"+ex.getMessage());
	        String p_name = "ravi";
	        String d_name = "suresh";
	        String address = "t-nagar";
	        String gender = "male";
	        String ap_date = "25/09/2023";
	        String ap_time = "11:00AM";
	        String disease = "bone fracture";

	        
	        Appointment fallbackAppointment = new Appointment(ap_id, p_name, d_name, address, gender, ap_date, ap_time, disease);

	        
	        return new ResponseEntity<>(fallbackAppointment, HttpStatus.OK);
	    }
}
