package com.example.service;

import java.util.Collections;

import java.util.List;

import java.util.Map;


import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;

import com.example.model.AdminSignUp;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("admin-service")
public interface AdminSignUpService {
	


	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodloginuser")
	@PostMapping("/adminlogin")
	public AdminSignUp loginuser(@RequestBody AdminSignUp admin);
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodregisterAdmin")
    @PostMapping("/registerAdmin")
	public AdminSignUp registerAdmin(@RequestBody AdminSignUp admin);
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodgetAdmin")
    @GetMapping("/getAdmin")
	public List<AdminSignUp> getAdmin();
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodgetAdminById")
	@GetMapping("/getAdminById/{adminId}")
	public AdminSignUp getAdminById(@PathVariable("adminId") int id);
	
	
	
	
	 default AdminSignUp fallbackMethodloginuser(AdminSignUp d, Throwable throwable) {
	        System.out.println("Fallback method for loginuser() called: " + throwable.getMessage());
	        return (AdminSignUp) Collections.emptyList();
	    }
	 
	 default AdminSignUp fallbackMethodregisterAdmin(AdminSignUp d, Throwable throwable) {
	        System.out.println("Fallback method for registerAdmin() called: " + throwable.getMessage());
	        return (AdminSignUp) Collections.emptyList();
	    }
	 

	    default List<AdminSignUp> fallbackMethodgetAdmin(Throwable throwable) {
	        System.out.println("Fallback method for getAdmin() called: " + throwable.getMessage());
	        return Collections.emptyList();
	    }
	    
	    default AdminSignUp fallbackMethodgetAdminById(int id, Throwable throwable) {
	        System.out.println("Fallback method for getAdminById() called: " + throwable.getMessage());
	        return new AdminSignUp();
	    }

}
