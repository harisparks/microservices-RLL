package com.example.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.model.AuthenticationStatus;
import com.example.model.PatientLogin;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("patient-service")
public interface PatientLoginService {

	@Retry(name = "patient-service")
	@CircuitBreaker(name = "patient-service", fallbackMethod = "fallbackMethodvalidatePatientLogin")
	@PostMapping("/patientlogin")
    public ResponseEntity<AuthenticationStatus> validatePatientLogin(@RequestBody PatientLogin patientLogin);

	default ResponseEntity<AuthenticationStatus> fallbackMethodvalidatePatientLogin(
            @RequestBody PatientLogin patientLogin, Throwable throwable) {
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(new AuthenticationStatus("Fallback: Unable to validate patient login", null, false));
    }
}