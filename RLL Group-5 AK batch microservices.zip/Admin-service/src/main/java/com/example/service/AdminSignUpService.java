package com.example.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.AdminSignUpRepository;
import com.example.model.AdminSignUp;




@Service
public class AdminSignUpService {

	@Autowired
	private AdminSignUpRepository repo;
	
	public AdminSignUp saveAdmin(AdminSignUp admin){
		return repo.save(admin);
		}
	public AdminSignUp fetchAdminByEmailId(String email)
	{
		return repo.findByEmailId(email);
	}
	
	public AdminSignUp fetchAdminByEmailIdandPassword(String email, String password)
	{
		return repo.findByEmailIdAndPassword(email, password);
		
	}
	public List<AdminSignUp> getAllAdmin(){
		return this.repo.findAll();
	}

	public AdminSignUp getAdminById(int id) {
		Optional<AdminSignUp> findById = this.repo.findById(id);
		return findById.get();
	}

}