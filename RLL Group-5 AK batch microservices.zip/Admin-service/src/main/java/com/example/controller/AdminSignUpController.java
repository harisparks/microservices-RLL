package com.example.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.model.AdminSignUp;
import com.example.service.AdminSignUpService;

@RestController
public class AdminSignUpController {
	@Autowired
	private AdminSignUpService service;
	
	private Logger log = LoggerFactory.getLogger(AdminSignUpController.class);
	

	 @PostMapping("/registerAdmin")
	    public AdminSignUp registerAdmin(@RequestBody AdminSignUp admin) throws Exception {
	        log.debug("Received request to register admin: {}", admin);

	        String tempEmailId = admin.getEmailId();
	        if (tempEmailId != null && !"".equals(tempEmailId)) {
	            AdminSignUp adminobj = service.fetchAdminByEmailId(tempEmailId);

	            if (adminobj != null) {
	                log.debug("Admin with email {} already exists", tempEmailId);
	                throw new Exception("Admin with " + tempEmailId + " already exists");
	            }
	        }
	        AdminSignUp adminObj = null;
	        adminObj = service.saveAdmin(admin);
	        log.debug("Admin registered: {}", adminObj);
	        return adminObj;
	    }

	    @PostMapping("/adminlogin")
	    public AdminSignUp loginuser(@RequestBody AdminSignUp admin) throws Exception {
	        log.debug("Received request for admin login: {}", admin);

	        String tempEmailId = admin.getEmailId();
	        String tempPass = admin.getPassword();
	        AdminSignUp adminObj = null;
	        if (tempEmailId != null && tempPass != null) {
	            adminObj = service.fetchAdminByEmailIdandPassword(tempEmailId, tempPass);
	        }
	        if (adminObj == null) {
	            log.debug("Bad credentials for email: {}", tempEmailId);
	            throw new Exception("Bad Credentials");
	        }

	        log.debug("Admin logged in: {}", adminObj);
	        return adminObj;
	    }

	    @GetMapping("/getAdmin")
	    public List<AdminSignUp> getAdmin() {
	        log.debug("Received request to retrieve all admins");
	        return this.service.getAllAdmin();
	    }

	    @GetMapping("/getAdminById/{adminId}")
	    public AdminSignUp getAdminById(@PathVariable("adminId") int id) {
	        log.debug("Received request to retrieve admin by ID: {}", id);
	        return this.service.getAdminById(id);
	    }
	}
	


