package com.example.controller;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.dao.FeedbackRepository;

import com.example.model.Feedback;
import com.example.service.FeedbackService;


@RestController
public class FeedbackController {
	@Autowired
	
	private FeedbackRepository feedbackrepository;
	private Logger log = LoggerFactory.getLogger(FeedbackController.class);
	
	@GetMapping("/feedbacks")
	
	public List<Feedback> getAllFeedbacks()
	{
		log.debug("In getAllDoctors with return value Doctors: " );
		return feedbackrepository.findAll();
		}


	@PostMapping("/feedbacks")
	public Feedback addFeedback(@RequestBody Feedback f) {
		log.debug("In addFeedback with Feedback: " + f);
		Feedback feedback = feedbackrepository.save(f);
		log.debug("In addFeedback with return value Feedback: " + feedback);
		return feedback;
	}

	

}