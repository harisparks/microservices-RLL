package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.dao.FeedbackRepository;

import com.example.model.Feedback;
@Service
public class FeedbackService {
	@Autowired
	FeedbackRepository feedbackrepository;
	
	public List<Feedback> fetchFeedbacks() {
		List<Feedback> feedbacklist=feedbackrepository.findAll();
		return feedbacklist;
		
	}
	
	public Feedback saveFeedbacks(Feedback feedback) {
		
		return feedbackrepository.save(feedback);
		

}
}